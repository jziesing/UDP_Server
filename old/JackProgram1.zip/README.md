cis432
======

Walter Sorenson and Jack Ziesing submission
client works
server works.  having trouble sending to say messages to your client.  server works well with our client.

please enjoy.
